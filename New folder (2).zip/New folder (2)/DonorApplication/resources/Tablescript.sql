 CREATE Table Donor_Details(Donor_Id VARCHAR(20),Donor_Name VARCHAR(20),Address VARCHAR(20),Phone_Number VARCHAR(20),Donor_Date DATE,Donor_Amount Number);

Table created.



SQL> CREATE SEQUENCE donorId_sequence START WITh 1000;

SQL>
SQL> select donorId_sequence.nextval from dual;

   NEXTVAL
----------
      1000

SQL> commit;