package com.cg.donor.exception;

import java.lang.reflect.Executable;

public class DonorException extends Exception
{

	public DonorException(String message) {
		
		
		super(message);
		// TODO Auto-generated constructor stub
	}

	
	
}
